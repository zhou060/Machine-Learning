import pandas as pd
import warnings
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.metrics import roc_auc_score
from catboost import CatBoostClassifier

# 忽略警告信息，避免输出过多的警告信息干扰结果
warnings.filterwarnings('ignore')

# 加载训练数据和测试数据
train = pd.read_csv("data/train.csv")
testA = pd.read_csv("data/testA.csv")

# 数据预处理函数，用于处理缺失值、日期和分类特征
def preprocess_data(data):
    # 选择数值型特征，并用中位数填充缺失值
    numerical_fea = list(data.select_dtypes(exclude=['object']).columns)
    if 'isDefault' in numerical_fea:
        numerical_fea.remove('isDefault')
    data[numerical_fea] = data[numerical_fea].fillna(data[numerical_fea].median())

    # 处理日期特征，提取年份和月份
    data['issueDate'] = pd.to_datetime(data['issueDate'], format='%Y-%m-%d')
    data['issueYear'] = data['issueDate'].dt.year
    data['issueMonth'] = data['issueDate'].dt.month

    # 将等级特征映射为数值
    data['grade'] = data['grade'].map({'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7})

    # 将就业年限映射为数值
    data['employmentLength'] = data['employmentLength'].map(
        {'1 year': 1, '2 years': 2, '3 years': 3, '4 years': 4, '5 years': 5, '6 years': 6, '7 years': 7, '8 years': 8,
         '9 years': 9, '10+ years': 10, '< 1 year': 0})

    # 将子等级映射为数值
    data['subGrade'] = data['subGrade'].map(
        {'E2': 1, 'D2': 2, 'D3': 3, 'A4': 4, 'C2': 5, 'A5': 6, 'C3': 7, 'B4': 8, 'B5': 9, 'E5': 10,
         'D4': 11, 'B3': 12, 'B2': 13, 'D1': 14, 'E1': 15, 'C5': 16, 'C1': 17, 'A2': 18, 'A3': 19, 'B1': 20,
         'E3': 21, 'F1': 22, 'C4': 23, 'A1': 24, 'D5': 25, 'F2': 26, 'E4': 27, 'F3': 28, 'G2': 29, 'F5': 30,
         'G3': 31, 'G1': 32, 'F4': 33, 'G4': 34, 'G5': 35})

    # 提取最早信用线的年份
    data['earliesCreditLine'] = data['earliesCreditLine'].str[-4:].astype(int)
    return data

# 预处理训练和测试数据
train = preprocess_data(train)
testA = preprocess_data(testA)

print("数据预处理完成!")

# 准备数据
# 创建提交文件的框架，包含测试集的id和预测的isDefault列
sub = testA[['id']].copy()
sub['isDefault'] = 0
# 去掉测试集中的id和issueDate列，这些列在模型训练中不需要
testA = testA.drop(['id', 'issueDate'], axis=1)
# 去掉训练集中的isDefault、id和issueDate列，这些列在模型训练中不需要
data_x = train.drop(['isDefault', 'id', 'issueDate'], axis=1)
# 提取训练集的目标变量isDefault
data_y = train[['isDefault']].copy()

# 分割数据为训练集和验证集
x, val_x, y, val_y = train_test_split(
    data_x,
    data_y,
    test_size=0.25,  # 验证集占25%
    random_state=1,  # 随机种子，保证结果可复现
    stratify=data_y  # 按照目标变量的比例进行分层抽样
)

# 设置分类特征，这些特征需要告知CatBoost模型是分类特征
cat_features = ['grade', 'subGrade', 'employmentTitle', 'homeOwnership', 'verificationStatus', 'purpose', 'postCode',
                'regionCode', 'initialListStatus', 'applicationType', 'policyCode']
# 将分类特征转换为字符串类型，这是CatBoost的要求
for col in cat_features:
    data_x[col] = data_x[col].astype('str')
    testA[col] = testA[col].astype('str')

# 初始化CatBoost模型
model = CatBoostClassifier(
    loss_function="Logloss",  # 损失函数为对数损失
    eval_metric="AUC",  # 评估指标为AUC
    task_type="GPU",  # 使用GPU加速训练
    learning_rate=0.05,  # 学习率
    iterations=2000,  # 迭代次数
    random_seed=2020,  # 随机种子
    od_type="Iter",  # 早停类型
    depth=6,  # 树的深度
    metric_period=1  # 每次迭代输出一次评估指标
)

# 使用StratifiedKFold进行交叉验证
mean_score = 0
n_folds = 5  # 交叉验证的折数
sk = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=2019)
answers = []  # 用于存储每折的预测结果
for train_idx, test_idx in sk.split(data_x, data_y):
    # 根据索引分割训练集和测试集
    x_train, y_train = data_x.iloc[train_idx], data_y.iloc[train_idx]
    x_test, y_test = data_x.iloc[test_idx], data_y.iloc[test_idx]
    # 训练模型
    clf = model.fit(x_train, y_train, eval_set=(x_test, y_test), verbose=500, cat_features=cat_features)
    # 预测测试集的概率
    yy_pred_valid = clf.predict_proba(x_test)[:, 1]
    # 计算当前折的AUC
    fold_auc = roc_auc_score(y_test, yy_pred_valid)
    print(f'当前折的 AUC: {fold_auc}')
    mean_score += fold_auc / n_folds  # 累加AUC，后续计算平均AUC
    # 预测测试集的概率
    y_pred_valid = clf.predict_proba(testA)[:, 1]
    answers.append(y_pred_valid)

# 输出平均验证AUC
print(f'平均验证 AUC: {mean_score}')
# 计算最终预测结果的平均值
cat_pre = sum(answers) / n_folds
# 将预测结果存储到提交文件中
sub['isDefault'] = cat_pre
# 将提交文件保存为CSV文件
sub.to_csv('金融预测结果.csv', index=False)